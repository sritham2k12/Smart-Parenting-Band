import json
import random
import time
from datetime import datetime


# ── Sensor Simulator ───────────────────────────────────────────────────────
class SensorSimulator:
    """
    Simulates real-time sensor readings from the Smart Parenting Band.
    In production, this connects to actual hardware sensors via serial/BLE.
    """

    def read_temperature(self):
        """Simulate child body temperature in Celsius."""
        return round(random.uniform(36.2, 39.5), 1)

    def read_heart_rate(self):
        """Simulate child heart rate in BPM."""
        return random.randint(70, 130)

    def read_activity(self):
        """Simulate activity level."""
        return random.choice(["sleeping", "resting", "active", "highly_active"])

    def read_location(self):
        """Simulate GPS coordinates (Hyderabad area)."""
        return {
            "lat": round(17.3850 + random.uniform(-0.01, 0.01), 6),
            "lng": round(78.4867 + random.uniform(-0.01, 0.01), 6)
        }

    def get_all_readings(self):
        """Return all sensor readings as a dict."""
        return {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "temperature": self.read_temperature(),
            "heart_rate": self.read_heart_rate(),
            "activity": self.read_activity(),
            "location": self.read_location()
        }


# ── Health Analyzer ────────────────────────────────────────────────────────
class HealthAnalyzer:
    """
    Analyzes sensor readings and detects health irregularities.
    Generates alerts for parents when abnormal values are detected.
    """

    # Normal ranges for children (age 3-10)
    TEMP_NORMAL = (36.1, 37.5)
    TEMP_FEVER = 38.0
    TEMP_HIGH_FEVER = 39.0
    HR_NORMAL = (70, 110)

    def analyze(self, reading):
        """Analyze a reading and return status + alerts."""
        alerts = []
        status = "normal"

        # Temperature check
        temp = reading["temperature"]
        if temp >= self.TEMP_HIGH_FEVER:
            alerts.append({
                "type": "HIGH_FEVER",
                "severity": "critical",
                "message": f"⚠️  HIGH FEVER detected: {temp}°C — Seek medical attention immediately!"
            })
            status = "critical"
        elif temp >= self.TEMP_FEVER:
            alerts.append({
                "type": "FEVER",
                "severity": "warning",
                "message": f"🌡️  Fever detected: {temp}°C — Monitor closely and consider medication."
            })
            status = "warning"

        # Heart rate check
        hr = reading["heart_rate"]
        if hr > self.HR_NORMAL[1]:
            alerts.append({
                "type": "HIGH_HEART_RATE",
                "severity": "warning",
                "message": f"💓 Elevated heart rate: {hr} BPM — Could be activity-related. Monitor."
            })
            if status == "normal":
                status = "warning"
        elif hr < self.HR_NORMAL[0]:
            alerts.append({
                "type": "LOW_HEART_RATE",
                "severity": "warning",
                "message": f"💓 Low heart rate: {hr} BPM — Please check on your child."
            })
            if status == "normal":
                status = "warning"

        return {"status": status, "alerts": alerts}


# ── Alert System ───────────────────────────────────────────────────────────
class AlertSystem:
    """
    Handles parent notifications.
    In production, this sends SMS/push notifications via an API.
    """

    def send_alert(self, child_name, alert):
        """Simulate sending an alert to parent's phone."""
        print(f"\n  📱 ALERT → Sent to parent for {child_name}")
        print(f"     [{alert['severity'].upper()}] {alert['message']}")

    def send_daily_summary(self, child_name, summary):
        """Send daily health summary to parent."""
        print(f"\n  📋 Daily Summary for {child_name}:")
        print(f"     Avg Temperature  : {summary['avg_temp']}°C")
        print(f"     Avg Heart Rate   : {summary['avg_hr']} BPM")
        print(f"     Fever Episodes   : {summary['fever_count']}")
        print(f"     Activity Today   : {summary['activity_summary']}")


# ── Data Logger ────────────────────────────────────────────────────────────
class DataLogger:
    """Logs all readings to a JSON file for history and analysis."""

    def __init__(self, filepath="data/readings_log.json"):
        self.filepath = filepath
        self.logs = []

    def log(self, child_name, reading, analysis):
        """Append a reading with its analysis to the log."""
        entry = {
            "child": child_name,
            "reading": reading,
            "analysis": analysis
        }
        self.logs.append(entry)

    def save(self):
        """Save all logs to JSON file."""
        import os
        os.makedirs("data", exist_ok=True)
        with open(self.filepath, "w") as f:
            json.dump(self.logs, f, indent=2)
        print(f"\n  💾 Logs saved → {self.filepath}")

    def get_daily_summary(self):
        """Calculate daily health summary from logs."""
        if not self.logs:
            return None
        temps = [l["reading"]["temperature"] for l in self.logs]
        hrs = [l["reading"]["heart_rate"] for l in self.logs]
        activities = [l["reading"]["activity"] for l in self.logs]
        fever_count = sum(1 for t in temps if t >= 38.0)
        activity_counts = {}
        for a in activities:
            activity_counts[a] = activity_counts.get(a, 0) + 1
        most_common = max(activity_counts, key=activity_counts.get)
        return {
            "avg_temp": round(sum(temps) / len(temps), 1),
            "avg_hr": round(sum(hrs) / len(hrs)),
            "fever_count": fever_count,
            "activity_summary": most_common
        }


# ── Main Monitor ───────────────────────────────────────────────────────────
class SmartParentingBand:
    """
    Main system that ties together sensor reading, health analysis,
    alert generation, and data logging.

    Patent: Smart Parenting Band — Manisritham Narsingoju (2024)
    """

    def __init__(self, child_name="Child"):
        self.child_name = child_name
        self.sensor = SensorSimulator()
        self.analyzer = HealthAnalyzer()
        self.alerts = AlertSystem()
        self.logger = DataLogger()

    def monitor_once(self, verbose=True):
        """Take one reading and process it."""
        reading = self.sensor.get_all_readings()
        analysis = self.analyzer.analyze(reading)

        self.logger.log(self.child_name, reading, analysis)

        if verbose:
            self._print_reading(reading, analysis)

        if analysis["alerts"]:
            for alert in analysis["alerts"]:
                self.alerts.send_alert(self.child_name, alert)

        return reading, analysis

    def monitor_continuous(self, readings=5, interval=2):
        """Continuously monitor for a set number of readings."""
        print("=" * 55)
        print(f"  👶 Smart Parenting Band — Monitoring: {self.child_name}")
        print(f"  📡 Taking {readings} readings every {interval}s")
        print("=" * 55)

        for i in range(readings):
            print(f"\n  Reading {i+1}/{readings}:")
            self.monitor_once()
            if i < readings - 1:
                time.sleep(interval)

        # Save logs and show summary
        self.logger.save()
        summary = self.logger.get_daily_summary()
        if summary:
            self.alerts.send_daily_summary(self.child_name, summary)

        print("\n✅ Monitoring session complete.")

    def _print_reading(self, reading, analysis):
        """Print a formatted reading to console."""
        status_icon = {"normal": "✅", "warning": "⚠️ ", "critical": "🚨"}.get(
            analysis["status"], "❓"
        )
        print(f"    {status_icon} Status     : {analysis['status'].upper()}")
        print(f"    🌡️  Temperature : {reading['temperature']}°C")
        print(f"    💓 Heart Rate  : {reading['heart_rate']} BPM")
        print(f"    🏃 Activity    : {reading['activity']}")
        print(f"    📍 Location    : {reading['location']['lat']}, {reading['location']['lng']}")
        print(f"    🕐 Time        : {reading['timestamp']}")


# ── Entry Point ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    band = SmartParentingBand(child_name="Arjun")
    band.monitor_continuous(readings=5, interval=1)
